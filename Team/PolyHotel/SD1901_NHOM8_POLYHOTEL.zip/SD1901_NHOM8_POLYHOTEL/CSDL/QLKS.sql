﻿
CREATE DATABASE QLKS;
GO
USE QLKS;
GO

--Bảng Khách Hàng
CREATE TABLE KhachHang (
  MaKH INT PRIMARY KEY,
  HoTen NVARCHAR(50) NOT NULL,
  SoDT NVARCHAR(20),
  Email NVARCHAR(50),
  CCCD NVARCHAR(20)
);

--Bảng Loại Phòng
CREATE TABLE LoaiPhong (
  MaLoai INT PRIMARY KEY,
  TenLoai NVARCHAR(50),
  MoTa NVARCHAR(100),
  GiaPhong INT
);

--Bảng Dịch Vụ
CREATE TABLE DichVu (
  MaDV INT PRIMARY KEY,
  TenDV NVARCHAR(50),
  MoTa NVARCHAR(100),
  DonGia INT
);

--Bảng Tình Trạng
CREATE TABLE TinhTrang (
  MaTinhTrang INT PRIMARY KEY,
  TenTT NVARCHAR(50)
);

--Bảng Tài Khoản
CREATE TABLE TaiKhoan (
  TenDangNhap NVARCHAR(30) PRIMARY KEY,
  MatKhau NVARCHAR(50),
  VaiTro NVARCHAR(30),
  TrangThaiTK NVARCHAR(30),
  NgayTao DATE,
  LanCuoi_DangNhap DATE
);


--Bảng Nhân Viên
CREATE TABLE NhanVien (
  MaNV INT PRIMARY KEY,
  HoTen NVARCHAR(50),
  GioiTinh NVARCHAR(10),
  SoDT NVARCHAR(20),
  NgaySinh DATE,
  Email NVARCHAR(50),
  DiaChi NVARCHAR(100),
  HinhAnh NVARCHAR(100), -- ✅ THÊM DÒNG NÀY
  TenDangNhap NVARCHAR(30),
  FOREIGN KEY (TenDangNhap) REFERENCES TaiKhoan(TenDangNhap)
);

--Bảng Hình thức thanh toán
CREATE TABLE HinhThuc_GiaoDich (
  MaHT INT PRIMARY KEY,
  TenHT NVARCHAR(50)
);

--Bảng Phòng
CREATE TABLE Phong (
  MaPhong INT IDENTITY(1,1) PRIMARY KEY,
  SoPhong NVARCHAR(10),
  MaLoai INT,
  MaTinhTrang INT,
  FOREIGN KEY (MaLoai) REFERENCES LoaiPhong(MaLoai),
  FOREIGN KEY (MaTinhTrang) REFERENCES TinhTrang(MaTinhTrang)
);

--Bảng Đặt Phòng
CREATE TABLE DatPhong (
    MaDatPhong INT IDENTITY(1,1) PRIMARY KEY,
    NgayDat DATE,
    NgayNhan DATE,
    NgayTra DATE,
    MaKH INT,
    MaPhong INT,
    FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH),
    FOREIGN KEY (MaPhong) REFERENCES Phong(MaPhong)
);

--Bảng Hoá Đơn
CREATE TABLE HoaDon (
    MaHD INT IDENTITY(1,1) PRIMARY KEY,
    MaDatPhong INT NOT NULL,
    MaHT INT NOT NULL,
    NgayTao DATETIME DEFAULT GETDATE(),
    NgayThanhToan DATETIME,
    TrangThaiHD NVARCHAR(50),
    MaNV INT,
    FOREIGN KEY (MaDatPhong) REFERENCES DatPhong(MaDatPhong),
    FOREIGN KEY (MaHT) REFERENCES HinhThuc_GiaoDich(MaHT),
    FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV)
);

--Bảng Chi tiết hoá đơn
CREATE TABLE CT_HoaDon (
  MaHD INT,
  MaDV INT,
  DonGia INT,
  SoLuong INT,
  GiamGia INT,
  NgaySuDung DATE,
  TongTien AS ((DonGia * SoLuong) - GiamGia) PERSISTED,
  PRIMARY KEY (MaHD, MaDV),
  FOREIGN KEY (MaHD) REFERENCES HoaDon(MaHD),
  FOREIGN KEY (MaDV) REFERENCES DichVu(MaDV)
); 

--Bảng Dịch vụ đã dùng
CREATE TABLE DichVuDaDung (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    MaDatPhong INT NOT NULL,
    MaDV INT NOT NULL,
    DonGia INT NOT NULL,
    SoLuong INT NOT NULL,
    GiamGia INT DEFAULT 0,
    NgaySuDung DATE DEFAULT GETDATE(),
    
    FOREIGN KEY (MaDatPhong) REFERENCES DatPhong(MaDatPhong),
    FOREIGN KEY (MaDV) REFERENCES DichVu(MaDV)
);

--KH
INSERT INTO KhachHang VALUES (1, N'John Smith', '0912345678', 'john1@example.com', '123456789');
INSERT INTO KhachHang VALUES (2, N'Emma Johnson', '0923456789', 'emma2@example.com', '234567891');
INSERT INTO KhachHang VALUES (3, N'Oliver Brown', '0934567890', 'oliver3@example.com', '345678912');
INSERT INTO KhachHang VALUES (4, N'Ava Taylor', '0945678901', 'ava4@example.com', '456789123');
INSERT INTO KhachHang VALUES (5, N'Liam Wilson', '0956789012', 'liam5@example.com', '567891234');
INSERT INTO KhachHang VALUES (6, N'Sophia Lee', '0967890123', 'sophia6@example.com', '678912345');
INSERT INTO KhachHang VALUES (7, N'Noah Harris', '0978901234', 'noah7@example.com', '789123456');
INSERT INTO KhachHang VALUES (8, N'Isabella Clark', '0989012345', 'bella8@example.com', '891234567');
INSERT INTO KhachHang VALUES (9, N'James Lewis', '0990123456', 'james9@example.com', '912345678');
INSERT INTO KhachHang VALUES (10, N'Mia Walker', '0901234567', 'mia10@example.com', '102345678');

--LP
INSERT INTO LoaiPhong VALUES (1, N'Single', N'1 người, tiện nghi cơ bản', 300000);
INSERT INTO LoaiPhong VALUES (2, N'Double', N'2 người, giường đôi', 500000);
INSERT INTO LoaiPhong VALUES (3, N'Twin', N'2 giường đơn', 450000);
INSERT INTO LoaiPhong VALUES (4, N'Deluxe', N'Phòng sang trọng', 700000);
INSERT INTO LoaiPhong VALUES (5, N'Suite', N'Phòng cao cấp', 1000000);
INSERT INTO LoaiPhong VALUES (6, N'Family', N'Dành cho gia đình', 900000);
INSERT INTO LoaiPhong VALUES (7, N'Standard', N'Tiện nghi cơ bản', 350000);
INSERT INTO LoaiPhong VALUES (8, N'VIP', N'Dịch vụ cao cấp', 1200000);
INSERT INTO LoaiPhong VALUES (9, N'Business', N'Dành cho công tác', 650000);
INSERT INTO LoaiPhong VALUES (10, N'Mini', N'Nhỏ gọn giá rẻ', 250000);

--DV
INSERT INTO DichVu VALUES (1, N'Bữa sáng', N'Bữa ăn sáng buffet', 50000);
INSERT INTO DichVu VALUES (2, N'Massage', N'Dịch vụ massage thư giãn', 200000);
INSERT INTO DichVu VALUES (3, N'Giặt ủi', N'Dịch vụ giặt đồ', 30000);
INSERT INTO DichVu VALUES (4, N'Internet', N'Wifi tốc độ cao', 0);
INSERT INTO DichVu VALUES (5, N'Taxi', N'Đặt xe taxi', 50000);
INSERT INTO DichVu VALUES (6, N'Đồ ăn', N'Phục vụ món ăn phòng', 100000);
INSERT INTO DichVu VALUES (7, N'Spa', N'Dịch vụ spa thư giãn', 400000);
INSERT INTO DichVu VALUES (8, N'Cafe', N'Cà phê tại sảnh', 20000);
INSERT INTO DichVu VALUES (9, N'Trái cây', N'Dĩa trái cây tươi', 30000);

--TT
INSERT INTO TinhTrang VALUES (1, N'Trống');
INSERT INTO TinhTrang VALUES (2, N'Đang sử dụng');
INSERT INTO TinhTrang VALUES (3, N'Đang dọn');
INSERT INTO TinhTrang VALUES (4, N'Bảo trì');
INSERT INTO TinhTrang VALUES (5, N'Khóa');
INSERT INTO TinhTrang VALUES (6, N'Hỏng');
INSERT INTO TinhTrang VALUES (7, N'Đặt trước');
INSERT INTO TinhTrang VALUES (8, N'Sắp trả');
INSERT INTO TinhTrang VALUES (9, N'Trễ');
INSERT INTO TinhTrang VALUES (10, N'Khác');

--TK
INSERT INTO TaiKhoan VALUES (N'user1', '123456', 'Admin', 'Hoạt động', GETDATE(), GETDATE());
INSERT INTO TaiKhoan VALUES (N'user2', '123456', 'Nhân viên', 'Hoạt động', GETDATE(), GETDATE());
INSERT INTO TaiKhoan VALUES (N'user3', '123456', 'Nhân viên', 'Hoạt động', GETDATE(), GETDATE());
INSERT INTO TaiKhoan VALUES (N'user4', '123456', 'Nhân viên', 'Hoạt động', GETDATE(), GETDATE());
INSERT INTO TaiKhoan VALUES (N'user5', '123456', 'Admin', 'Khóa', GETDATE(), GETDATE());
INSERT INTO TaiKhoan VALUES (N'user6', '123456', 'Nhân viên', 'Hoạt động', GETDATE(), GETDATE());
INSERT INTO TaiKhoan VALUES (N'user7', '123456', 'Admin', 'Khóa', GETDATE(), GETDATE());
INSERT INTO TaiKhoan VALUES (N'user8', '123456', 'Nhân viên', 'Hoạt động', GETDATE(), GETDATE());
INSERT INTO TaiKhoan VALUES (N'user9', '123456', 'Admin', 'Khóa', GETDATE(), GETDATE());
INSERT INTO TaiKhoan VALUES (N'user10', '123456', 'Nhân viên', 'Hoạt động', GETDATE(), GETDATE());

--NV
INSERT INTO NhanVien (MaNV, HoTen, GioiTinh, SoDT, NgaySinh, Email, DiaChi, TenDangNhap, HinhAnh)
VALUES
(1, N'Norma Fisher', N'Nữ', '876-475-93', '2000-08-09', 'kyleblair@hotmail.com', N'6593 Ramos Pike, Bryanside, AL 12726', N'user1','user1.jpg'),
(2, N'Jennifer Summers', N'Nữ', '+1-097-535', '1982-04-21', 'jrodriguez@yahoo.com', N'398 Wallace Ranch Suite 593, Ivanburgh, RI 86570', N'user2','user2.jpg'),
(3, N'Benjamin Shelton', N'Nam', '(201)868-4', '2002-09-08', 'shannon51@yahoo.com', N'533 Jessica Crescent Apt. 525, Cabreraville, FL 91946', N'user3','user3.jpg'),
(4, N'Robert Walters', N'Nữ', '+1-910-139', '1992-02-28', 'jacobsjames@robbins.com', N'086 Mary Cliff, North Deborah, NE 24135', N'user4','user4.jpg'),
(5, N'John Carlson', N'Nữ', '001-634-57', '1988-02-05', 'awade@maldonado-mccullough.net', N'PSC 5642, Box 8071, APO AA 97365', N'user5','user5.jpg'),
(6, N'Douglas Allen', N'Nữ', '594.599.24', '2003-05-03', 'johnwalsh@yahoo.com', N'69602 Brown Squares Apt. 787, North Troyport, NH 07035', N'user6','user6.jpg'),
(7, N'Sheri Burnett', N'Nữ', '812.066.50', '2003-12-22', 'leecharlene@russo.com', N'104 Marsh Crescent Suite 285, Port Erictown, AZ 27467', N'user7','user7.jpg'),
(8, N'Kristin Potts', N'Nữ', '001-097-76', '1999-07-18', 'taylorjoseph@yahoo.com', N'9004 Edward Prairie, Michaelside, LA 15560', N'user8','user8.jpg'),
(9, N'David Williams', N'Nữ', '(814)654-6', '1995-12-09', 'mary51@yahoo.com', N'0452 Courtney Lane Apt. 113, North Paul, MO 73439', N'user9','user9.jpg'),
(10, N'Joan Burns', N'Nam', '001-361-53', '1991-10-07', 'shortmelissa@leach.com', N'3039 Daniel Mount Suite 582, New Tonyaberg, MO 84172', N'user10','user10.jpg');

--HTTT
INSERT INTO HinhThuc_GiaoDich VALUES (1, N'Tiền mặt');
INSERT INTO HinhThuc_GiaoDich VALUES (2, N'Chuyển khoản');
INSERT INTO HinhThuc_GiaoDich VALUES (3, N'Momo');
INSERT INTO HinhThuc_GiaoDich VALUES (4, N'ZaloPay');
INSERT INTO HinhThuc_GiaoDich VALUES (5, N'ShopeePay');
INSERT INTO HinhThuc_GiaoDich VALUES (6, N'Thẻ tín dụng');
INSERT INTO HinhThuc_GiaoDich VALUES (7, N'Thẻ ATM');
INSERT INTO HinhThuc_GiaoDich VALUES (8, N'VNPay');
INSERT INTO HinhThuc_GiaoDich VALUES (9, N'Paypal');
INSERT INTO HinhThuc_GiaoDich VALUES (10, N'Khác');

--Phong
INSERT INTO Phong (SoPhong, MaLoai, MaTinhTrang) VALUES ('P101', 9, 3);
INSERT INTO Phong (SoPhong, MaLoai, MaTinhTrang) VALUES ('P102', 5, 3);
INSERT INTO Phong (SoPhong, MaLoai, MaTinhTrang) VALUES ('P103', 2, 10);
INSERT INTO Phong (SoPhong, MaLoai, MaTinhTrang) VALUES ('P104', 5, 9);
INSERT INTO Phong (SoPhong, MaLoai, MaTinhTrang) VALUES ('P105', 10, 3);
INSERT INTO Phong (SoPhong, MaLoai, MaTinhTrang) VALUES ('P106', 5, 2);
INSERT INTO Phong (SoPhong, MaLoai, MaTinhTrang) VALUES ('P201', 2, 6);
INSERT INTO Phong (SoPhong, MaLoai, MaTinhTrang) VALUES ('P202', 8, 9);
INSERT INTO Phong (SoPhong, MaLoai, MaTinhTrang) VALUES ('P203', 2, 6);
INSERT INTO Phong (SoPhong, MaLoai, MaTinhTrang) VALUES ('P204', 7, 6);

--DP
SET IDENTITY_INSERT DatPhong ON;

INSERT INTO DatPhong (MaDatPhong ,NgayDat, NgayNhan, NgayTra, MaKH, MaPhong)
VALUES 
 (1, '2025-07-17', '2025-07-29', '2025-07-30', 10, 4),
 (2, '2025-07-12', '2025-07-24', '2025-07-30', 9, 8),
 (3, '2025-07-06', '2025-07-19', '2025-07-24', 8, 9),
 (4, '2025-06-27', '2025-07-13', '2025-07-30', 5, 1),
 (5, '2025-07-12', '2025-07-19', '2025-07-19', 9, 1),
 (6, '2025-07-22', '2025-07-23', '2025-07-26', 2, 7),
 (7, '2025-07-26', '2025-07-26', '2025-07-31', 1, 10),
 (8, '2025-07-15', '2025-07-29', '2025-07-29', 8, 6),
 (9, '2025-07-19', '2025-07-19', '2025-07-21', 4, 6),
 (10, '2025-07-22', '2025-07-22', '2025-07-22', 2, 4);

SET IDENTITY_INSERT DatPhong OFF;

--Hoá đơn
-- BẬT để chèn MaHD thủ công
SET IDENTITY_INSERT HoaDon ON;

INSERT INTO HoaDon (MaHD, MaDatPhong, MaHT, NgayTao, NgayThanhToan, TrangThaiHD, MaNV) VALUES
(1, 1, 1, '2025-07-30', '2025-07-30', N'Đã thanh toán', 1),
(2, 2, 2, '2025-07-30', '2025-07-30', N'Chưa thanh toán', 2),
(3, 3, 3, '2025-07-24', '2025-07-24', N'Đã thanh toán', 3),
(4, 4, 4, '2025-07-30', '2025-07-30', N'Đã thanh toán', 4),
(5, 5, 5, '2025-07-19', '2025-07-19', N'Đã thanh toán', 5),
(6, 6, 6, '2025-07-26', '2025-07-26', N'Chưa thanh toán', 6),
(7, 7, 7, '2025-07-31', '2025-07-31', N'Đã thanh toán', 7),
(8, 8, 8, '2025-07-29', '2025-07-29', N'Chưa thanh toán', 8),
(9, 9, 9, '2025-07-21', '2025-07-21', N'Đã thanh toán', 9),
(10, 10, 10, '2025-07-22', '2025-07-22', N'Đã thanh toán', 10);

-- TẮT lại sau khi chèn
SET IDENTITY_INSERT HoaDon OFF;

--CT_HD
INSERT INTO CT_HoaDon (MaHD, MaDV, DonGia, SoLuong, GiamGia, NgaySuDung) VALUES
(1, 1, 50000, 1, 5000, '2025-07-30'),
(2, 2, 200000, 1, 0, '2025-07-30'),
(3, 3, 30000, 3, 0, '2025-07-24'),
(4, 4, 0, 1, 0, '2025-07-30'),
(5, 5, 50000, 2, 0, '2025-07-19'),
(6, 6, 100000, 1, 10000, '2025-07-26'),
(7, 7, 400000, 1, 50000, '2025-07-31'),
(8, 8, 20000, 2, 0, '2025-07-29'),
(9, 9, 30000, 1, 0, '2025-07-21');

--DV đã dùng
INSERT INTO DichVuDaDung (MaDatPhong, MaDV, DonGia, SoLuong, GiamGia)
VALUES 
(1, 2, 200000, 1, 0),   -- 2 chai nước suối
(1, 1, 50000, 1, 5000); -- 1 phần đồ ăn trừ 5k


--Theo ngày
CREATE PROCEDURE sp_ThongKe_DoanhThu_Ngay
AS
BEGIN
    SELECT 
        CONVERT(DATE, hd.NgayThanhToan) AS Ngay,
        SUM(cthd.TongTien) AS TongDoanhThu
    FROM 
        HoaDon hd
    JOIN 
        CT_HoaDon cthd ON hd.MaHD = cthd.MaHD
    WHERE 
        hd.TrangThaiHD = N'Đã thanh toán'
    GROUP BY 
        CONVERT(DATE, hd.NgayThanhToan)
    ORDER BY 
        Ngay;
END;
 
--Theo tháng
CREATE PROCEDURE sp_ThongKe_DoanhThu_Thang
AS
BEGIN
    SELECT 
        YEAR(hd.NgayThanhToan) AS Nam,
        MONTH(hd.NgayThanhToan) AS Thang,
        SUM(cthd.TongTien) AS TongDoanhThu
    FROM 
        HoaDon hd
    JOIN 
        CT_HoaDon cthd ON hd.MaHD = cthd.MaHD
    WHERE 
        hd.TrangThaiHD = N'Đã thanh toán'
    GROUP BY 
        YEAR(hd.NgayThanhToan), MONTH(hd.NgayThanhToan)
    ORDER BY 
        Nam, Thang;
END;

--Theo năm
CREATE PROCEDURE sp_ThongKe_DoanhThu_Nam
AS
BEGIN
    SELECT 
        YEAR(hd.NgayThanhToan) AS Nam,
        SUM(cthd.TongTien) AS TongDoanhThu
    FROM 
        HoaDon hd
    JOIN 
        CT_HoaDon cthd ON hd.MaHD = cthd.MaHD
    WHERE 
        hd.TrangThaiHD = N'Đã thanh toán'
    GROUP BY 
        YEAR(hd.NgayThanhToan)
    ORDER BY 
        Nam;
END;

--Theo nhân viên lập hóa đơn
CREATE PROCEDURE sp_ThongKe_DoanhThu_TheoNhanVien
AS
BEGIN
    SELECT 
        nv.MaNV,
        nv.HoTen,
        SUM(cthd.TongTien) AS TongDoanhThu
    FROM 
        HoaDon hd
    JOIN 
        CT_HoaDon cthd ON hd.MaHD = cthd.MaHD
    JOIN 
        NhanVien nv ON hd.MaNV = nv.MaNV
    WHERE 
        hd.TrangThaiHD = N'Đã thanh toán'
    GROUP BY 
        nv.MaNV, nv.HoTen
    ORDER BY 
        TongDoanhThu DESC;
END;

--Theo dịch vụ sử dụng
CREATE PROCEDURE sp_ThongKe_DoanhThu_TheoDichVu
AS
BEGIN
    SELECT 
        dv.MaDV,
        dv.TenDV,
        SUM(cthd.SoLuong) AS TongSoLuong,
        SUM(cthd.TongTien) AS DoanhThu
    FROM 
        CT_HoaDon cthd
    JOIN 
        DichVu dv ON cthd.MaDV = dv.MaDV
    GROUP BY 
        dv.MaDV, dv.TenDV
    ORDER BY 
        DoanhThu DESC;
END;

--Câu truy vấn
EXEC sp_ThongKe_DoanhThu_Ngay;
EXEC sp_ThongKe_DoanhThu_Thang
EXEC sp_ThongKe_DoanhThu_TheoNhanVien;
EXEC sp_ThongKe_DoanhThu_TheoDichVu;

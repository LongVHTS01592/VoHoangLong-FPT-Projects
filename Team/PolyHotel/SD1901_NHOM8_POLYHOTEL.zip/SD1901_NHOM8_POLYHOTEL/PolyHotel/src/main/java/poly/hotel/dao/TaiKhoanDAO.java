package poly.hotel.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.hotel.entity.TaiKhoan;
import poly.hotel.util.XJDBC;

public class TaiKhoanDAO {

    // Câu lệnh SQL
    private final String INSERT_SQL = "INSERT INTO TaiKhoan (TenDangNhap, MatKhau, VaiTro, TrangThaiTK, NgayTao, LanCuoi_DangNhap) VALUES (?, ?, ?, ?, GETDATE(), NULL)";
    private final String UPDATE_SQL = "UPDATE TaiKhoan SET MatKhau = ?, VaiTro = ?, TrangThaiTK = ? WHERE TenDangNhap = ?";
    private final String DELETE_SQL = "DELETE FROM TaiKhoan WHERE TenDangNhap = ?";
    private final String SELECT_ALL_SQL = "SELECT * FROM TaiKhoan";
    private final String SELECT_BY_ID_SQL = "SELECT * FROM TaiKhoan WHERE TenDangNhap = ?";

    // Thêm tài khoản
    public void insert(TaiKhoan tk) {
        try {
            XJDBC.update(INSERT_SQL,
                tk.getTenDangNhap(),
                tk.getMatKhau(),
                tk.getVaiTro(),
                tk.getTrangThai()
            );
        } catch (Exception e) {
            throw new RuntimeException("Lỗi thêm tài khoản: " + e.getMessage(), e);
        }
    }

    // Cập nhật tài khoản
    public void update(TaiKhoan tk) {
        try {
            XJDBC.update(UPDATE_SQL,
                tk.getMatKhau(),
                tk.getVaiTro(),
                tk.getTrangThai(),
                tk.getTenDangNhap()
            );
        } catch (Exception e) {
            throw new RuntimeException("Lỗi cập nhật tài khoản: " + e.getMessage(), e);
        }
    }

    // Xóa tài khoản
    public void delete(String tenDangNhap) {
        try {
            XJDBC.update(DELETE_SQL, tenDangNhap);
        } catch (Exception e) {
            throw new RuntimeException("Lỗi xóa tài khoản: " + e.getMessage(), e);
        }
    }

    // Lấy tất cả tài khoản
    public List<TaiKhoan> selectAll() {
        return selectBySql(SELECT_ALL_SQL);
    }

    // Lấy tài khoản theo ID (TenDangNhap)
    public TaiKhoan selectById(String tenDangNhap) {
        List<TaiKhoan> list = selectBySql(SELECT_BY_ID_SQL, tenDangNhap);
        return list.size() > 0 ? list.get(0) : null;
    }

    // Hàm chung thực thi SQL trả về danh sách
    private List<TaiKhoan> selectBySql(String sql, Object... args) {
        List<TaiKhoan> list = new ArrayList<>();
        try {
            ResultSet rs = XJDBC.query(sql, args);
            while (rs.next()) {
                TaiKhoan tk = new TaiKhoan();
                tk.setTenDangNhap(rs.getString("TenDangNhap"));
                tk.setMatKhau(rs.getString("MatKhau"));
                tk.setVaiTro(rs.getString("VaiTro"));
                tk.setTrangThai(rs.getString("TrangThaiTK"));
                tk.setNgayTao(rs.getDate("NgayTao"));
                tk.setLanCuoiDangNhap(rs.getDate("LanCuoi_DangNhap"));
                list.add(tk);
            }
            rs.getStatement().getConnection().close();
        } catch (Exception e) {
            throw new RuntimeException("Lỗi truy vấn tài khoản: " + e.getMessage(), e);
        }
        return list;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.hotel.entity;

import java.util.Date;

/**
 *
 * @author Admin
 */
public class DatPhong {

    private int maDatPhong;
    private Date ngayDat;
    private Date ngayNhan;
    private Date ngayTra;
    private int maKH;
    private int maPhong;

    public DatPhong() {
    }

    public DatPhong(int maDatPhong, Date ngayDat, Date ngayNhan, Date ngayTra, int maKH, int maPhong) {
        this.maDatPhong = maDatPhong;
        this.ngayDat = ngayDat;
        this.ngayNhan = ngayNhan;
        this.ngayTra = ngayTra;
        this.maKH = maKH;
        this.maPhong = maPhong;
    }

    public int getMaDatPhong() {
        return maDatPhong;
    }

    public void setMaDatPhong(int maDatPhong) {
        this.maDatPhong = maDatPhong;
    }

    public Date getNgayDat() {
        return ngayDat;
    }

    public void setNgayDat(Date ngayDat) {
        this.ngayDat = ngayDat;
    }

    public Date getNgayNhan() {
        return ngayNhan;
    }

    public void setNgayNhan(Date ngayNhan) {
        this.ngayNhan = ngayNhan;
    }

    public Date getNgayTra() {
        return ngayTra;
    }

    public void setNgayTra(Date ngayTra) {
        this.ngayTra = ngayTra;
    }

    public int getMaKH() {
        return maKH;
    }

    public void setMaKH(int maKH) {
        this.maKH = maKH;
    }

    public int getMaPhong() {
        return maPhong;
    }

    public void setMaPhong(int maPhong) {
        this.maPhong = maPhong;
    }

    @Override
    public String toString() {
        return "DatPhong{"
                + "maDatPhong=" + maDatPhong
                + ", ngayDat=" + ngayDat
                + ", ngayNhan=" + ngayNhan
                + ", ngayTra=" + ngayTra
                + ", maKH=" + maKH
                + ", maPhong=" + maPhong
                + '}';
    }
}

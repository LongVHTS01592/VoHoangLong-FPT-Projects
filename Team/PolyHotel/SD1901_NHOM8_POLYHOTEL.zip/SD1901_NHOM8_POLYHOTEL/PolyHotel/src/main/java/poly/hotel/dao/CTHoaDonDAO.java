/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.hotel.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.hotel.util.XJDBC;

/**
 *
 * @author Admin
 */
public class CTHoaDonDAO {

    public List<Object[]> selectByMaHD(int maHD) {
        String sql = """
            SELECT dv.TenDV, ct.DonGia, ct.SoLuong, ct.GiamGia, ct.TongTien
            FROM CT_HoaDon ct
            JOIN DichVu dv ON ct.MaDV = dv.MaDV
            WHERE ct.MaHD = ?
        """;

        List<Object[]> list = new ArrayList<>();
        try (ResultSet rs = XJDBC.query(sql, maHD)) {
            while (rs.next()) {
                Object[] row = {
                    rs.getString("TenDV"),
                    rs.getInt("DonGia"),
                    rs.getInt("SoLuong"),
                    rs.getInt("GiamGia"),
                    rs.getInt("TongTien")
                };
                list.add(row);
            }
            rs.getStatement().getConnection().close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Object[]> getCTHoaDonByMaHD(int maHD) {
        String sql = "SELECT dv.TenDV, ct.SoLuong, ct.DonGia, ct.TongTien "
                + "FROM CT_HoaDon ct JOIN DichVu dv ON ct.MaDV = dv.MaDV "
                + "WHERE ct.MaHD = ?";
        List<Object[]> list = new ArrayList<>();
        try (ResultSet rs = XJDBC.query(sql, maHD)) {
            while (rs.next()) {
                Object[] row = {
                    rs.getString("TenDV"),
                    rs.getInt("SoLuong"),
                    rs.getInt("DonGia"),
                    rs.getInt("TongTien")
                };
                list.add(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public int getTongTienDV(int maHD) {
        String sql = "SELECT SUM(TongTien) FROM CT_HoaDon WHERE MaHD = ?";
        try (ResultSet rs = XJDBC.query(sql, maHD)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean exists(int maHD, int maDV) {
        String sql = "SELECT COUNT(*) FROM CT_HoaDon WHERE MaHD = ? AND MaDV = ?";
        try (ResultSet rs = XJDBC.query(sql, maHD, maDV)) {
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public void insertOrUpdate(int maHD, int maDV, int donGia, int soLuong, int giamGia) {
        if (exists(maHD, maDV)) {
            // Nếu đã tồn tại thì UPDATE
            String sql = """
            UPDATE CT_HoaDon
            SET SoLuong = SoLuong + ?,
                TongTien = (SoLuong + ?) * DonGia - GiamGia
            WHERE MaHD = ? AND MaDV = ?
        """;
            XJDBC.update(sql, soLuong, soLuong, maHD, maDV);
        } else {
            // Nếu chưa có thì INSERT mới
            String sql = """
            INSERT INTO CT_HoaDon (MaHD, MaDV, DonGia, SoLuong, GiamGia, TongTien, NgaySuDung)
            VALUES (?, ?, ?, ?, ?, (? * ?) - ?, GETDATE())
        """;
            XJDBC.update(sql, maHD, maDV, donGia, soLuong, giamGia, donGia, soLuong, giamGia);
        }
    }
}

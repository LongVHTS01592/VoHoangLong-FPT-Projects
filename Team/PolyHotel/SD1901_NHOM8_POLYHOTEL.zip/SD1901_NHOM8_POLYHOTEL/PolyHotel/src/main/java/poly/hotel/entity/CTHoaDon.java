/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.hotel.entity;

import java.util.Date;

/**
 *
 * @author Admin
 */
public class CTHoaDon {

    private int maHD;
    private int maDV;
    private int donGia;
    private int soLuong;
    private int giamGia;
    private Date ngaySuDung;
    private int tongTien;

    public CTHoaDon() {
    }

    public CTHoaDon(int maHD, int maDV, int donGia, int soLuong, int giamGia, Date ngaySuDung, int tongTien) {
        this.maHD = maHD;
        this.maDV = maDV;
        this.donGia = donGia;
        this.soLuong = soLuong;
        this.giamGia = giamGia;
        this.ngaySuDung = ngaySuDung;
        this.tongTien = tongTien;
    }

    public int getMaHD() {
        return maHD;
    }

    public void setMaHD(int maHD) {
        this.maHD = maHD;
    }

    public int getMaDV() {
        return maDV;
    }

    public void setMaDV(int maDV) {
        this.maDV = maDV;
    }

    public int getDonGia() {
        return donGia;
    }

    public void setDonGia(int donGia) {
        this.donGia = donGia;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public int getGiamGia() {
        return giamGia;
    }

    public void setGiamGia(int giamGia) {
        this.giamGia = giamGia;
    }

    public Date getNgaySuDung() {
        return ngaySuDung;
    }

    public void setNgaySuDung(Date ngaySuDung) {
        this.ngaySuDung = ngaySuDung;
    }

    public int getTongTien() {
        return tongTien;
    }

    public void setTongTien(int tongTien) {
        this.tongTien = tongTien;
    }
}

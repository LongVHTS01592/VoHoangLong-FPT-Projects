package poly.hotel.service;

import java.sql.ResultSet;
import java.util.Date;
import poly.hotel.util.XJDBC;

public class HoaDonService {

    public int getTienPhongByMaHD(int maHD) {
        String sql = """
        SELECT DATEDIFF(DAY, dp.NgayNhan, dp.NgayTra) AS SoNgay, lp.GiaPhong
        FROM HoaDon hd
        JOIN DatPhong dp ON hd.MaDatPhong = dp.MaDatPhong
        JOIN Phong p ON dp.MaPhong = p.MaPhong
        JOIN LoaiPhong lp ON p.MaLoai = lp.MaLoai
        WHERE hd.MaHD = ?
    """;
        try (ResultSet rs = XJDBC.query(sql, maHD)) {
            if (rs.next()) {
                int soNgay = rs.getInt("SoNgay");
                int giaPhong = rs.getInt("GiaPhong");
                return soNgay * giaPhong;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public String getTenKhachHangByMaHD(int maHD) {
        String sql = "SELECT kh.HoTen FROM HoaDon hd "
                + "JOIN DatPhong dp ON hd.MaDatPhong = dp.MaDatPhong "
                + "JOIN KhachHang kh ON dp.MaKH = kh.MaKH "
                + "WHERE hd.MaHD = ?";
        try (ResultSet rs = XJDBC.query(sql, maHD)) {
            if (rs.next()) {
                return rs.getString(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public Date getNgayLapByMaHD(int maHD) {
        String sql = "SELECT NgayTao FROM HoaDon WHERE MaHD = ?";
        try (ResultSet rs = XJDBC.query(sql, maHD)) {
            if (rs.next()) {
                return rs.getDate(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void chuyenDichVuSangChiTietHoaDon(int maHD, int maDatPhong) {
        String sql = """
        SELECT MaDV, DonGia, SoLuong, GiamGia
        FROM DichVuDaDung
        WHERE MaDatPhong = ?
    """;
        try (ResultSet rs = XJDBC.query(sql, maDatPhong)) {
            while (rs.next()) {
                int maDV = rs.getInt("MaDV");
                int donGia = rs.getInt("DonGia");
                int soLuong = rs.getInt("SoLuong");
                int giamGia = rs.getInt("GiamGia");

                String insert = "INSERT INTO CT_HoaDon (MaHD, MaDV, DonGia, SoLuong, GiamGia, NgaySuDung) "
                        + "VALUES (?, ?, ?, ?, ?, GETDATE())";
                XJDBC.update(insert, maHD, maDV, donGia, soLuong, giamGia);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}

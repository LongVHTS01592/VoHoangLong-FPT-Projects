/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.hotel.entity;

/**
 *
 * @author Admin
 */
public class LoaiPhong {

    private int maLoai;
    private String tenLoai;
    private String moTa;
    private int giaPhong;

    public LoaiPhong() {
    }

    public LoaiPhong(int maLoai, String tenLoai, String moTa, int giaPhong) {
        this.maLoai = maLoai;
        this.tenLoai = tenLoai;
        this.moTa = moTa;
        this.giaPhong = giaPhong;
    }

    public int getMaLoai() {
        return maLoai;
    }

    public void setMaLoai(int maLoai) {
        this.maLoai = maLoai;
    }

    public String getTenLoai() {
        return tenLoai;
    }

    public void setTenLoai(String tenLoai) {
        this.tenLoai = tenLoai;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public int getGiaPhong() {
        return giaPhong;
    }

    public void setGiaPhong(int giaPhong) {
        this.giaPhong = giaPhong;
    }

    @Override
    public String toString() {
        return this.getTenLoai(); // hoặc tên thuộc tính bạn muốn hiển thị
    }

}

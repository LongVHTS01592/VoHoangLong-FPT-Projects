package poly.hotel.dao;

import java.sql.*;
import java.util.*;
import poly.hotel.entity.Phong;
import poly.hotel.util.XJDBC;

public class PhongDAO {

    final String SELECT_ALL_SQL = "SELECT * FROM Phong";
    final String SELECT_BY_ID_SQL = "SELECT * FROM Phong WHERE MaPhong=?";

    public List<Phong> selectAll() {
        List<Phong> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Phong";
            Connection conn = XJDBC.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                list.add(new Phong(
                        rs.getInt("MaPhong"),
                        rs.getString("SoPhong"),
                        rs.getInt("MaLoai"),
                        rs.getInt("MaTinhTrang")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public Phong selectById(int maPhong) {
        try {
            String sql = "SELECT * FROM Phong WHERE MaPhong = ?";
            Connection conn = XJDBC.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, maPhong);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Phong(
                        rs.getInt("MaPhong"),
                        rs.getString("SoPhong"),
                        rs.getInt("MaLoai"),
                        rs.getInt("MaTinhTrang")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    protected List<Phong> selectBySql(String sql, Object... args) {
        List<Phong> list = new ArrayList<>();
        try {
            ResultSet rs = XJDBC.query(sql, args);
            while (rs.next()) {
                Phong p = new Phong();
                p.setMaPhong(rs.getInt("MaPhong"));
                p.setSoPhong(rs.getString("SoPhong"));
                p.setMaLoai(rs.getInt("MaLoai"));
                p.setMaTinhTrang(rs.getInt("MaTinhTrang"));
                list.add(p);
            }
            rs.getStatement().getConnection().close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    public void update(Phong p) {
        try {
            String sql = "UPDATE Phong SET SoPhong = ?, MaLoai = ?, MaTinhTrang = ? WHERE MaPhong = ?";
            Connection conn = XJDBC.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, p.getSoPhong());
            ps.setInt(2, p.getMaLoai());
            ps.setInt(3, p.getMaTinhTrang());
            ps.setInt(4, p.getMaPhong());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(Integer id) {
        String sql = "DELETE FROM Phong WHERE MaPhong = ?";
        XJDBC.update(sql, id);
    }

    public void insert(Phong entity) {
        String sql = "INSERT INTO Phong (SoPhong, MaLoai, MaTinhTrang) VALUES (?, ?, ?)";
        XJDBC.update(sql, entity.getSoPhong(), entity.getMaLoai(), entity.getMaTinhTrang());
    }

    public Phong selectBySoPhong(String soPhong) {
        String sql = "SELECT * FROM Phong WHERE SoPhong = ?";
        List<Phong> list = selectBySql(sql, soPhong);
        return list.isEmpty() ? null : list.get(0);
    }
}

package poly.hotel.util;

import java.awt.Component;
import javax.swing.JOptionPane;

/**
 * Tiện ích hiển thị hộp thoại (thông báo, xác nhận, nhập liệu)
 */
public class XDialog {

    // Thông báo với title mặc định
    public static void alert(Component parent, String message) {
        alert(parent, message, "Thông báo!");
    }

    // Thông báo với title tùy chọn
    public static void alert(Component parent, String message, String title) {
        JOptionPane.showMessageDialog(parent, message, title, JOptionPane.INFORMATION_MESSAGE);
    }

    // Xác nhận với title mặc định
    public static boolean confirm(Component parent, String message) {
        return confirm(parent, message, "Xác nhận!");
    }

    // Xác nhận với title tùy chọn
    public static boolean confirm(Component parent, String message, String title) {
        int result = JOptionPane.showConfirmDialog(parent, message, title, JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        return result == JOptionPane.YES_OPTION;
    }

    // Hộp nhập liệu với title mặc định
    public static String prompt(Component parent, String message) {
        return prompt(parent, message, "Nhập vào!");
    }

    // Hộp nhập liệu với title tùy chọn
    public static String prompt(Component parent, String message, String title) {
        return JOptionPane.showInputDialog(parent, message, title, JOptionPane.QUESTION_MESSAGE);
    }
}

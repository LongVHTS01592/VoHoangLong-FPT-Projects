/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.hotel.entity;

/**
 *
 * @author Admin
 */
public class HTGD {

    private int maHT;
    private String tenHT;

    public HTGD(int maHT, String tenHT) {
        this.maHT = maHT;
        this.tenHT = tenHT;
    }

    public HTGD() {
    }

    public int getMaHT() {
        return maHT;
    }

    public void setMaHT(int maHT) {
        this.maHT = maHT;
    }

    public String getTenHT() {
        return tenHT;
    }

    public void setTenHT(String tenHT) {
        this.tenHT = tenHT;
    }

    @Override
    public String toString() {
        return tenHT; // Dùng cho ComboBox
    }
}

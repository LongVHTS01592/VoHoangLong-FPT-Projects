package poly.hotel.util;

import poly.hotel.entity.NhanVien;

public class XAuth {
    public static NhanVien user = null;

    public static void clear() {
        user = null;
    }

    public static boolean isLogin() {
        return user != null;
    }

    public static boolean isAdmin() {
        return isLogin() && user.getVaiTro().equalsIgnoreCase("Admin");
    }
}

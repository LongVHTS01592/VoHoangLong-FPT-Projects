/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.hotel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.hotel.entity.LoaiPhong;
import poly.hotel.util.XJDBC;

/**
 *
 * @author Admin
 */
public class LoaiPhongDAO {
    public List<LoaiPhong> findAll() {
        String sql = "SELECT * FROM LoaiPhong";
        List<LoaiPhong> list = new ArrayList<>();
        try (ResultSet rs = XJDBC.query(sql)) {
            while (rs.next()) {
                LoaiPhong lp = new LoaiPhong();
                lp.setMaLoai(rs.getInt("MaLoai"));
                lp.setTenLoai(rs.getString("TenLoai"));
                lp.setMoTa(rs.getString("MoTa"));
                lp.setGiaPhong(rs.getInt("GiaPhong"));
                list.add(lp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public LoaiPhong findById(int maLoai) {
        String sql = "SELECT * FROM LoaiPhong WHERE MaLoai = ?";
        try (ResultSet rs = XJDBC.query(sql, maLoai)) {
            if (rs.next()) {
                return new LoaiPhong(
                    rs.getInt("MaLoai"),
                    rs.getString("TenLoai"),
                    rs.getString("MoTa"),
                    rs.getInt("GiaPhong")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void insert(LoaiPhong lp) {
        String sql = "INSERT INTO LoaiPhong (MaLoai, TenLoai, MoTa, GiaPhong) VALUES (?, ?, ?, ?)";
        XJDBC.update(sql, lp.getMaLoai(), lp.getTenLoai(), lp.getMoTa(), lp.getGiaPhong());
    }

    public void update(LoaiPhong lp) {
        String sql = "UPDATE LoaiPhong SET TenLoai=?, MoTa=?, GiaPhong=? WHERE MaLoai=?";
        XJDBC.update(sql, lp.getTenLoai(), lp.getMoTa(), lp.getGiaPhong(), lp.getMaLoai());
    }

    public void delete(int maLoai) {
        String sql = "DELETE FROM LoaiPhong WHERE MaLoai=?";
        XJDBC.update(sql, maLoai);
    }
    public LoaiPhong selectById(int maLoai) {
        try {
            String sql = "SELECT * FROM LoaiPhong WHERE MaLoai = ?";
            Connection conn = XJDBC.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, maLoai);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new LoaiPhong(
                    rs.getInt("MaLoai"),
                    rs.getString("TenLoai"),
                    rs.getString("MoTa"),
                    rs.getInt("GiaPhong")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}

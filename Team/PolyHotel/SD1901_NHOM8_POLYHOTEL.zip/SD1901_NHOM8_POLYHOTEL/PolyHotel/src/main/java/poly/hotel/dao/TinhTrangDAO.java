/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.hotel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.hotel.entity.TinhTrang;
import poly.hotel.util.XJDBC;

/**
 *
 * @author Admin
 */
public class TinhTrangDAO {

    public List<TinhTrang> findAll() {
        String sql = "SELECT * FROM TinhTrang";
        List<TinhTrang> list = new ArrayList<>();
        try (ResultSet rs = XJDBC.query(sql)) {
            while (rs.next()) {
                TinhTrang tt = new TinhTrang();
                tt.setMaTinhTrang(rs.getInt("MaTinhTrang"));
                tt.setTenTT(rs.getString("TenTT"));
                list.add(tt);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<TinhTrang> selectAll() {
        String sql = "SELECT * FROM TinhTrang";
        List<TinhTrang> list = new ArrayList<>();
        try (ResultSet rs = XJDBC.query(sql)) {
            while (rs.next()) {
                TinhTrang tt = new TinhTrang();
                tt.setMaTinhTrang(rs.getInt("MaTinhTrang"));
                tt.setTenTT(rs.getString("TenTT"));
                list.add(tt);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void insert(TinhTrang tt) {
        String sql = "INSERT INTO TinhTrang (MaTinhTrang, TenTT) VALUES (?, ?)";
        XJDBC.update(sql, tt.getMaTinhTrang(), tt.getTenTT());
    }

    public void update(TinhTrang tt) {
        String sql = "UPDATE TinhTrang SET TenTT=? WHERE MaTinhTrang=?";
        XJDBC.update(sql, tt.getTenTT(), tt.getMaTinhTrang());
    }

    public void delete(int maTT) {
        String sql = "DELETE FROM TinhTrang WHERE MaTinhTrang=?";
        XJDBC.update(sql, maTT);
    }

    public TinhTrang selectById(int maTT) {
        try {
            String sql = "SELECT * FROM TinhTrang WHERE MaTinhTrang = ?";
            Connection conn = XJDBC.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, maTT);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new TinhTrang(
                        rs.getInt("MaTinhTrang"),
                        rs.getString("TenTT")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}

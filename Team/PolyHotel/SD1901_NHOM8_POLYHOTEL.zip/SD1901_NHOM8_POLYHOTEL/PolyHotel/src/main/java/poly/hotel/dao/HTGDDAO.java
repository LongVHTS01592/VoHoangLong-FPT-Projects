package poly.hotel.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.hotel.entity.HTGD;
import poly.hotel.util.XJDBC;

public class HTGDDAO {

    // Trả về danh sách tất cả hình thức
    public List<HTGD> selectAll() {
        String sql = "SELECT * FROM HinhThuc_GiaoDich";
        return selectBySql(sql);
    }

    // Tìm kiếm theo từ khóa (tìm theo tên)
    public List<HTGD> findByKeyword(String keyword) {
        List<HTGD> list = new ArrayList<>();
        String sql = "SELECT * FROM HinhThuc_GiaoDich WHERE MaHT LIKE ? OR TenHT LIKE ?";
        try (ResultSet rs = XJDBC.query(sql, "%" + keyword + "%", "%" + keyword + "%")) {
            while (rs.next()) {
                HTGD ht = new HTGD();
                ht.setMaHT(rs.getInt("MaHT"));
                ht.setTenHT(rs.getString("TenHT"));
                list.add(ht);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Thêm mới
    public void insert(HTGD ht) {
        String sql = "INSERT INTO HinhThuc_GiaoDich (MaHT, TenHT) VALUES (?, ?)";
        XJDBC.update(sql, ht.getMaHT(), ht.getTenHT());
    }

    // Cập nhật
    public void update(HTGD ht) {
        String sql = "UPDATE HinhThuc_GiaoDich SET TenHT = ? WHERE MaHT = ?";
        XJDBC.update(sql, ht.getTenHT(), ht.getMaHT());
    }

    // Xóa
    public void delete(String maHT) {
        String sql = "DELETE FROM HinhThuc_GiaoDich WHERE MaHT = ?";
        XJDBC.update(sql, maHT);
    }

    // Dùng chung để xử lý các câu lệnh truy vấn SELECT
    private List<HTGD> selectBySql(String sql, Object... args) {
        List<HTGD> list = new ArrayList<>();
        try (ResultSet rs = XJDBC.query(sql, args)) {
            while (rs.next()) {
                HTGD ht = new HTGD();
                ht.setMaHT(rs.getInt("MaHT"));
                ht.setTenHT(rs.getString("TenHT"));
                list.add(ht);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}

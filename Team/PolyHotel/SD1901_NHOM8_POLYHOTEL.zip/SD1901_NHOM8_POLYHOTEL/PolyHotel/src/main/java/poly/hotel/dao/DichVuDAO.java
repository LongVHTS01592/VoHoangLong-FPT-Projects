package poly.hotel.dao;

import java.sql.*;
import java.util.*;
import poly.hotel.entity.DichVu;
import poly.hotel.util.XJDBC;

public class DichVuDAO {

    public void insert(DichVu dv) {
        String sql = "INSERT INTO DichVu (MaDV, TenDV, MoTa, DonGia) VALUES (?, ?, ?, ?)";
        XJDBC.update(sql, dv.getMaDV(), dv.getTenDV(), dv.getMoTa(), dv.getDonGia());
    }

    public void update(DichVu dv) {
        String sql = "UPDATE DichVu SET TenDV=?, MoTa=?, DonGia=? WHERE MaDV=?";
        XJDBC.update(sql, dv.getTenDV(), dv.getMoTa(), dv.getDonGia(), dv.getMaDV());
    }

    public void delete(int maDV) {
        String sql = "DELETE FROM DichVu WHERE MaDV=?";
        XJDBC.update(sql, maDV);
    }

    public DichVu findById(int maDV) {
        String sql = "SELECT * FROM DichVu WHERE MaDV=?";
        try (ResultSet rs = XJDBC.query(sql, maDV)) {
            if (rs.next()) {
                return new DichVu(
                        rs.getInt("MaDV"),
                        rs.getString("TenDV"),
                        rs.getString("MoTa"),
                        rs.getInt("DonGia")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<DichVu> selectAll() {
        String sql = "SELECT * FROM DichVu";
        List<DichVu> list = new ArrayList<>();
        try (ResultSet rs = XJDBC.query(sql)) {
            while (rs.next()) {
                DichVu dv = new DichVu(
                        rs.getInt("MaDV"),
                        rs.getString("TenDV"),
                        rs.getString("MoTa"),
                        rs.getInt("DonGia")
                );
                list.add(dv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<DichVu> findByName(String keyword) {
        String sql = "SELECT * FROM DichVu WHERE TenDV LIKE ?";
        List<DichVu> list = new ArrayList<>();
        try (ResultSet rs = XJDBC.query(sql, "%" + keyword + "%")) {
            while (rs.next()) {
                DichVu dv = new DichVu(
                        rs.getInt("MaDV"),
                        rs.getString("TenDV"),
                        rs.getString("MoTa"),
                        rs.getInt("DonGia")
                );
                list.add(dv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package poly.hotel.polyhotel;

/**
 *
 * @author Admin
 */
public class PolyHotel {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

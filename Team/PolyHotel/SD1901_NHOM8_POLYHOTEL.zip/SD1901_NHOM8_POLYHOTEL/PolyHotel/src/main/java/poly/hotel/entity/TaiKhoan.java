/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.hotel.entity;

import java.util.Date;

/**
 *
 * @author Admin
 */
public class TaiKhoan {
    private String tenDangNhap;
    private String matKhau;
    private String vaiTro;
    private String trangThai;
    private Date ngayTao;
    private Date lanCuoiDangNhap;

    // Getter, Setter

    public TaiKhoan(String tenDangNhap, String matKhau, String vaiTro, String trangThai, Date ngayTao, Date lanCuoiDangNhap) {
        this.tenDangNhap = tenDangNhap;
        this.matKhau = matKhau;
        this.vaiTro = vaiTro;
        this.trangThai = trangThai;
        this.ngayTao = ngayTao;
        this.lanCuoiDangNhap = lanCuoiDangNhap;
    }

    public TaiKhoan(String username, String string, String string0, String đã_xóa) {
    }

    public TaiKhoan() {
    }

    public String getTenDangNhap() {
        return tenDangNhap;
    }

    public void setTenDangNhap(String tenDangNhap) {
        this.tenDangNhap = tenDangNhap;
    }

    public String getMatKhau() {
        return matKhau;
    }

    public void setMatKhau(String matKhau) {
        this.matKhau = matKhau;
    }

    public String getVaiTro() {
        return vaiTro;
    }

    public void setVaiTro(String vaiTro) {
        this.vaiTro = vaiTro;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

    public Date getLanCuoiDangNhap() {
        return lanCuoiDangNhap;
    }

    public void setLanCuoiDangNhap(Date lanCuoiDangNhap) {
        this.lanCuoiDangNhap = lanCuoiDangNhap;
    }
    
    
}

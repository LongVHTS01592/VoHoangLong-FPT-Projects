package poly.hotel.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.hotel.entity.HoaDon;
import poly.hotel.util.XJDBC;

public class HoaDonDAO {
    
    public List<HoaDon> findAll() {
        String sql = "SELECT * FROM HoaDon";
        List<HoaDon> list = new ArrayList<>();
        try (ResultSet rs = XJDBC.query(sql)) {
            while (rs.next()) {
                HoaDon hd = new HoaDon();
                hd.setMaHD(rs.getInt("MaHD"));
                hd.setNgayTao(rs.getDate("NgayTao"));
                hd.setNgayThanhToan(rs.getDate("NgayThanhToan"));
                hd.setTrangThaiHD(rs.getString("TrangThaiHD"));
                hd.setMaDatPhong(rs.getInt("MaDatPhong"));
                hd.setMaNV(rs.getInt("MaNV"));
                hd.setMaHT(rs.getInt("MaHT"));
                list.add(hd);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // ✅ MỚI: Dùng để load dữ liệu bảng JTable ở HoaDonJDialog
    public List<Object[]> selectHoaDonTable() {
        String sql = "SELECT hd.MaHD, kh.HoTen, hd.NgayTao, hd.NgayThanhToan, ht.TenHT, hd.TrangThaiHD "
                   + "FROM HoaDon hd "
                   + "JOIN DatPhong dp ON hd.MaDatPhong = dp.MaDatPhong "
                   + "JOIN KhachHang kh ON dp.MaKH = kh.MaKH "
                   + "JOIN HinhThuc_GiaoDich ht ON hd.MaHT = ht.MaHT";
        List<Object[]> list = new ArrayList<>();
        try (ResultSet rs = XJDBC.query(sql)) {
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("MaHD"),
                    rs.getString("HoTen"),
                    rs.getDate("NgayTao"),
                    rs.getDate("NgayThanhToan"),
                    rs.getString("TenHT"),
                    rs.getString("TrangThaiHD")
                };
                list.add(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}

package poly.hotel.entity;

import poly.hotel.dao.LoaiPhongDAO;
import poly.hotel.dao.TinhTrangDAO;

public class Phong {

    private int maPhong;
    private String soPhong;
    private int maLoai;
    private int maTinhTrang;

    public Phong() {
    }

    public Phong(int maPhong, String soPhong, int maLoai, int maTinhTrang) {
        this.maPhong = maPhong;
        this.soPhong = soPhong;
        this.maLoai = maLoai;
        this.maTinhTrang = maTinhTrang;
    }

    public int getMaPhong() {
        return maPhong;
    }

    public void setMaPhong(int maPhong) {
        this.maPhong = maPhong;
    }

    public String getSoPhong() {
        return soPhong;
    }

    public void setSoPhong(String soPhong) {
        this.soPhong = soPhong;
    }

    public int getMaLoai() {
        return maLoai;
    }

    public void setMaLoai(int maLoai) {
        this.maLoai = maLoai;
    }

    public int getMaTinhTrang() {
        return maTinhTrang;
    }

    public void setMaTinhTrang(int maTinhTrang) {
        this.maTinhTrang = maTinhTrang;
    }

    public LoaiPhong getLoaiPhong() {
        return new LoaiPhongDAO().selectById(maLoai);
    }

    public TinhTrang getTinhTrang() {
        return new TinhTrangDAO().selectById(maTinhTrang);
    }
}

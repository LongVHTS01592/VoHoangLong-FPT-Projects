package poly.hotel.dao;

import java.sql.*;
import java.util.*;
import poly.hotel.entity.KhachHang;
import poly.hotel.util.XJDBC;

public class KhachHangDAO {

    // Trả về danh sách tất cả khách hàng
    public List<KhachHang> findAll() {
        String sql = "SELECT * FROM KhachHang";
        List<KhachHang> list = new ArrayList<>();
        try (ResultSet rs = XJDBC.query(sql)) {
            while (rs.next()) {
                KhachHang kh = new KhachHang();
                kh.setMaKH(rs.getInt("MaKH"));
                kh.setHoTen(rs.getString("HoTen"));
                kh.setSoDT(rs.getString("SoDT"));
                kh.setEmail(rs.getString("Email"));
                kh.setCccd(rs.getString("CCCD"));
                list.add(kh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Tìm khách hàng theo mã
    public KhachHang findById(int maKH) {
        String sql = "SELECT * FROM KhachHang WHERE MaKH = ?";
        try (ResultSet rs = XJDBC.query(sql, maKH)) {
            if (rs.next()) {
                return new KhachHang(
                        rs.getInt("MaKH"),
                        rs.getString("HoTen"),
                        rs.getString("SoDT"),
                        rs.getString("Email"),
                        rs.getString("CCCD")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // Thêm khách hàng
    public void insert(KhachHang kh) {
        String sql = "INSERT INTO KhachHang (MaKH, HoTen, SoDT, Email, CCCD) VALUES (?, ?, ?, ?, ?)";
        XJDBC.update(sql, kh.getMaKH(), kh.getHoTen(), kh.getSoDT(), kh.getEmail(), kh.getCccd());
    }

    // Cập nhật khách hàng
    public void update(KhachHang kh) {
        String sql = "UPDATE KhachHang SET HoTen = ?, SoDT = ?, Email = ?, CCCD = ? WHERE MaKH = ?";
        XJDBC.update(sql, kh.getHoTen(), kh.getSoDT(), kh.getEmail(), kh.getCccd(), kh.getMaKH());
    }

    // Xoá khách hàng theo mã
    public void delete(int maKH) {
        String sql = "DELETE FROM KhachHang WHERE MaKH = ?";
        XJDBC.update(sql, maKH);
    }

    // Lấy danh sách khách hàng (dùng cho fillTable)
    public List<KhachHang> selectAll() {
        return findAll();
    }

    // Tìm khách hàng theo tên gần đúng (tùy chọn)
    public List<KhachHang> findByName(String keyword) {
        String sql = "SELECT * FROM KhachHang WHERE HoTen LIKE ?";
        List<KhachHang> list = new ArrayList<>();
        try (ResultSet rs = XJDBC.query(sql, "%" + keyword + "%")) {
            while (rs.next()) {
                KhachHang kh = new KhachHang(
                        rs.getInt("MaKH"),
                        rs.getString("HoTen"),
                        rs.getString("SoDT"),
                        rs.getString("Email"),
                        rs.getString("CCCD")
                );
                list.add(kh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public KhachHang selectById(int maKH) {
        return findById(maKH);
    }
}

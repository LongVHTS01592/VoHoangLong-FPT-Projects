package poly.hotel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.hotel.util.XJDBC;

public class DichVuDaDungDAO {

    public void deleteById(int id) {
        String sql = "{CALL sp_DichVuDaDung_DeleteByID(?)}";
        try (Connection conn = XJDBC.getConnection();
             java.sql.CallableStatement cs = conn.prepareCall(sql)) {
            cs.setInt(1, id);
            cs.execute();
        } catch (Exception e) {
            throw new RuntimeException("Lỗi khi xoá dịch vụ đã dùng: " + e.getMessage(), e);
        }
    }

    // Lấy danh sách dịch vụ đã dùng theo MaDatPhong
    public List<Object[]> getByMaDatPhong(int maDatPhong) {
        List<Object[]> list = new ArrayList<>();
        String sql = """
            SELECT ID, dv.TenDV, DonGia, SoLuong, GiamGia, 
                   (DonGia * SoLuong) - ISNULL(GiamGia,0) AS ThanhTien
            FROM DichVuDaDung dud
            JOIN DichVu dv ON dv.MaDV = dud.MaDV
            WHERE MaDatPhong = ?
            """;
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, maDatPhong);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Object[]{
                    rs.getInt("ID"),
                    rs.getString("TenDV"),
                    rs.getInt("DonGia"),
                    rs.getInt("SoLuong"),
                    rs.getInt("GiamGia"),
                    rs.getInt("ThanhTien")
                });
            }
        } catch (Exception e) {
            throw new RuntimeException("Lỗi load dịch vụ đã dùng: " + e.getMessage(), e);
        }
        return list;
    }
}

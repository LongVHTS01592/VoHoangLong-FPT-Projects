/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.hotel.entity;

/**
 *
 * @author Admin
 */
public class TinhTrang {

    private int maTinhTrang;
    private String tenTT;

    public TinhTrang() {
    }

    public TinhTrang(int maTinhTrang, String tenTT) {
        this.maTinhTrang = maTinhTrang;
        this.tenTT = tenTT;
    }

    public int getMaTinhTrang() {
        return maTinhTrang;
    }

    public void setMaTinhTrang(int maTinhTrang) {
        this.maTinhTrang = maTinhTrang;
    }

    public String getTenTT() {
        return tenTT;
    }

    public void setTenTT(String tenTT) {
        this.tenTT = tenTT;
    }

    @Override
    public String toString() {
        return this.getTenTT(); // hoặc tên hiển thị của tình trạng
    }

}

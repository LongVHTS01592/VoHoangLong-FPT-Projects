package poly.hotel.service;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class ForgotPasswordService {

    public static void sendResetPasswordEmail(String toEmail) throws Exception {
        String fromEmail = "trangvtts01830@gmail.com";  // Gmail của bạn
        String appPassword = "cdly jolh ozst hjfe"; // App password

        // Tạo mật khẩu mới ngẫu nhiên (hoặc lấy trong DB)
        String newPassword = "123456";

        // Cấu hình SMTP
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(fromEmail, appPassword);
            }
        });

        Message msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress(fromEmail, "PolyHotel", "UTF-8")); // Tên hiển thị UTF-8
        msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
        msg.setSubject(MimeUtility.encodeText("Khôi phục mật khẩu", "UTF-8", "B"));
        msg.setContent(
                "<div style='font-family: Arial, sans-serif; font-size: 14px; color: #333;'>"
                + "<h2 style='color:#2E86C1;'>Khôi phục mật khẩu</h2>"
                + "<p>Xin chào,</p>"
                + "<p>Mật khẩu mới của bạn là:</p>"
                + "<p style='font-size:18px; font-weight:bold; color:#D35400;'>"
                + newPassword + "</p>"
                + "<br/>"
                + "<p style='font-size:12px; color:#888;'>Vui lòng đăng nhập và đổi mật khẩu ngay sau khi sử dụng để đảm bảo an toàn.</p>"
                + "<hr style='border:none; border-top:1px solid #ddd;'/>"
                + "<p style='font-size:11px; color:#aaa;'>Email này được gửi tự động từ hệ thống PolyHotel. Vui lòng không trả lời lại.</p>"
                + "</div>",
                "text/html; charset=UTF-8"
        );

        Transport.send(msg);

        // TODO: Cập nhật mật khẩu mới vào DB
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.hotel.entity;

import java.util.Date;

/**
 *
 * @author Admin
 */
public class HoaDon {

    private int maHD;
    private Date ngayTao;
    private Date ngayThanhToan;
    private String trangThaiHD;
    private int maDatPhong;
    private int maNV;
    private int maHT;

    public HoaDon() {
    }

    public HoaDon(int maHD, Date ngayTao, Date ngayThanhToan, String trangThaiHD, int maDatPhong, int maNV, int maHT) {
        this.maHD = maHD;
        this.ngayTao = ngayTao;
        this.ngayThanhToan = ngayThanhToan;
        this.trangThaiHD = trangThaiHD;
        this.maDatPhong = maDatPhong;
        this.maNV = maNV;
        this.maHT = maHT;
    }

    public int getMaHD() {
        return maHD;
    }

    public void setMaHD(int maHD) {
        this.maHD = maHD;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

    public Date getNgayThanhToan() {
        return ngayThanhToan;
    }

    public void setNgayThanhToan(Date ngayThanhToan) {
        this.ngayThanhToan = ngayThanhToan;
    }

    public String getTrangThaiHD() {
        return trangThaiHD;
    }

    public void setTrangThaiHD(String trangThaiHD) {
        this.trangThaiHD = trangThaiHD;
    }

    public int getMaDatPhong() {
        return maDatPhong;
    }

    public void setMaDatPhong(int maDatPhong) {
        this.maDatPhong = maDatPhong;
    }

    public int getMaNV() {
        return maNV;
    }

    public void setMaNV(int maNV) {
        this.maNV = maNV;
    }

    public int getMaHT() {
        return maHT;
    }

    public void setMaHT(int maHT) {
        this.maHT = maHT;
    }
}

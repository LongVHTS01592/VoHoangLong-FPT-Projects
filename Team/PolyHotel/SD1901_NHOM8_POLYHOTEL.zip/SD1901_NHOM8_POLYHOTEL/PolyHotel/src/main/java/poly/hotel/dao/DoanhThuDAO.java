package poly.hotel.dao;

import java.sql.*;
import java.util.*;
import poly.hotel.util.XJDBC;

public class DoanhThuDAO {

    public double getTienPhong(java.util.Date tuNgay, java.util.Date denNgay) {
        String sql = """
            SELECT SUM(DATEDIFF(DAY, dp.NgayNhan, dp.NgayTra) * lp.GiaPhong)
            FROM HoaDon hd
            JOIN DatPhong dp ON hd.MaDatPhong = dp.MaDatPhong
            JOIN Phong p ON dp.MaPhong = p.MaPhong
            JOIN LoaiPhong lp ON p.MaLoai = lp.MaLoai
            WHERE hd.NgayThanhToan BETWEEN ? AND ? AND hd.TrangThaiHD = N'Đã thanh toán'
        """;
        return getValue(sql, tuNgay, denNgay);
    }

    public double getTienDichVu(java.util.Date tuNgay, java.util.Date denNgay) {
        String sql = """
            SELECT SUM(cthd.DonGia * cthd.SoLuong - cthd.GiamGia)
            FROM CT_HoaDon cthd
            JOIN HoaDon hd ON cthd.MaHD = hd.MaHD
            WHERE hd.NgayThanhToan BETWEEN ? AND ? AND hd.TrangThaiHD = N'Đã thanh toán'
        """;
        return getValue(sql, tuNgay, denNgay);
    }

    private double getValue(String sql, java.util.Date tu, java.util.Date den) {
        try (ResultSet rs = XJDBC.query(sql, new java.sql.Date(tu.getTime()), new java.sql.Date(den.getTime()))) {
            if (rs.next()) {
                return rs.getDouble(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}

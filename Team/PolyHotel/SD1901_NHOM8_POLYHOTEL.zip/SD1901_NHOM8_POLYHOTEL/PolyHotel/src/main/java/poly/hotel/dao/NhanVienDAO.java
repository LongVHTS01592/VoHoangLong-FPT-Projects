/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.hotel.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.hotel.entity.NhanVien;
import poly.hotel.util.XJDBC;

/**
 *
 * @author Admin
 */
public class NhanVienDAO {
    public void insert(NhanVien nv) {
        String sql = "INSERT INTO NhanVien (MaNV, HoTen, GioiTinh, SoDT, NgaySinh, Email, DiaChi, TenDangNhap) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        XJDBC.update(sql,
            nv.getMaNV(),
            nv.getHoTen(),
            nv.getGioiTinh(),
            nv.getSoDT(),
            new java.sql.Date(nv.getNgaySinh().getTime()),
            nv.getEmail(),
            nv.getDiaChi(),
            nv.getTenDangNhap()
        );
    }

    public void update(NhanVien nv) {
        String sql = "UPDATE NhanVien SET HoTen=?, GioiTinh=?, SoDT=?, NgaySinh=?, Email=?, DiaChi=?, VaiTro=?, TrangThai=? WHERE MaNV=?";

        XJDBC.update(sql,
            nv.getHoTen(),
            nv.getGioiTinh(),
            nv.getSoDT(),
            new java.sql.Date(nv.getNgaySinh().getTime()),
            nv.getEmail(),
            nv.getDiaChi(),
            nv.getTenDangNhap(),
            nv.getMaNV()
        );
    }

    public void delete(int maNV) {
        String sql = "DELETE FROM NhanVien WHERE MaNV=?";
        XJDBC.update(sql, maNV);
    }

    public List<NhanVien> selectAll() {
        String sql = """
            SELECT nv.*, tk.TenDangNhap
            FROM NhanVien nv
            JOIN TaiKhoan tk ON nv.TenDangNhap = tk.TenDangNhap
        """;
        return selectBySql(sql);
    }

    private List<NhanVien> selectBySql(String sql, Object... args) {
        List<NhanVien> list = new ArrayList<>();
        try (ResultSet rs = XJDBC.query(sql, args)) {
            while (rs.next()) {
                NhanVien nv = new NhanVien();
                nv.setMaNV(rs.getInt("MaNV"));
                nv.setHoTen(rs.getString("HoTen"));
                nv.setGioiTinh(rs.getString("GioiTinh"));
                nv.setSoDT(rs.getString("SoDT"));
                nv.setNgaySinh(rs.getDate("NgaySinh"));
                nv.setEmail(rs.getString("Email"));
                nv.setDiaChi(rs.getString("DiaChi"));
                nv.setTenDangNhap(rs.getString("TenDangNhap"));
                list.add(nv);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }
    
    public NhanVien findByTenDangNhap(String tenDangNhap) {
    String sql = "SELECT * FROM NhanVien WHERE TenDangNhap = ?";
    try (ResultSet rs = XJDBC.query(sql, tenDangNhap)) {
        if (rs.next()) {
            NhanVien nv = new NhanVien();
            nv.setMaNV(rs.getInt("MaNV"));
            nv.setHoTen(rs.getString("HoTen"));
            nv.setHinhAnh(rs.getString("HinhAnh"));
            nv.setTenDangNhap(rs.getString("TenDangNhap"));
            // bổ sung các trường khác nếu cần
            return nv;
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return null;
}
}

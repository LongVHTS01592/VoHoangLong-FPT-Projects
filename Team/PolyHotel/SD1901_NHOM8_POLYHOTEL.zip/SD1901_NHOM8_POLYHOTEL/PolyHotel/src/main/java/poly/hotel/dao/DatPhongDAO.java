package poly.hotel.dao;

import java.sql.*;
import java.util.*;
import poly.hotel.entity.DatPhong;
import poly.hotel.util.MsgBox;
import poly.hotel.util.XJDBC;

public class DatPhongDAO {

    final String INSERT_SQL = "INSERT INTO DatPhong (MaDatPhong, NgayDat, NgayNhan, NgayTra, MaKH, MaPhong) VALUES (?, ?, ?, ?, ?, ?)";
    final String SELECT_ALL_SQL = "SELECT * FROM DatPhong";
    final String SELECT_BY_ID_SQL = "SELECT * FROM DatPhong WHERE MaDatPhong = ?";

    public void insert(DatPhong dp) {
        XJDBC.update(INSERT_SQL,
                dp.getMaDatPhong(),
                new java.sql.Date(dp.getNgayDat().getTime()),
                new java.sql.Date(dp.getNgayNhan().getTime()),
                new java.sql.Date(dp.getNgayTra().getTime()),
                dp.getMaKH(),
                dp.getMaPhong()
        );
    }

    public List<DatPhong> selectAll() {
        List<DatPhong> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM DatPhong";
            Connection conn = XJDBC.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                DatPhong dp = new DatPhong(
                        rs.getInt("MaDatPhong"),
                        rs.getDate("NgayDat"),
                        rs.getDate("NgayNhan"),
                        rs.getDate("NgayTra"),
                        rs.getInt("MaKH"),
                        rs.getInt("MaPhong")
                );
                list.add(dp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public DatPhong selectById(int id) {
        List<DatPhong> list = selectBySql(SELECT_BY_ID_SQL, id);
        return list.isEmpty() ? null : list.get(0);
    }

    protected List<DatPhong> selectBySql(String sql, Object... args) {
        List<DatPhong> list = new ArrayList<>();
        try {
            ResultSet rs = XJDBC.query(sql, args);
            while (rs.next()) {
                DatPhong dp = new DatPhong();
                dp.setMaDatPhong(rs.getInt("MaDatPhong"));
                dp.setNgayDat(rs.getDate("NgayDat"));
                dp.setNgayNhan(rs.getDate("NgayNhan"));
                dp.setNgayTra(rs.getDate("NgayTra"));
                dp.setMaKH(rs.getInt("MaKH"));
                dp.setMaPhong(rs.getInt("MaPhong"));
                list.add(dp);
            }
            rs.getStatement().getConnection().close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    public int insertReturnID(DatPhong dp) {
        try {
            String sql = "INSERT INTO DatPhong (NgayDat, NgayNhan, NgayTra, MaKH, MaPhong) VALUES (?, ?, ?, ?, ?)";
            Connection conn = XJDBC.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setDate(1, new java.sql.Date(dp.getNgayDat().getTime()));
            ps.setDate(2, new java.sql.Date(dp.getNgayNhan().getTime()));
            ps.setDate(3, new java.sql.Date(dp.getNgayTra().getTime()));
            ps.setInt(4, dp.getMaKH());
            ps.setInt(5, dp.getMaPhong());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    public void delete(int maDatPhong) {
        try {
            // Xóa chi tiết hóa đơn
            String sqlCTHD = """
            DELETE FROM CT_HoaDon 
            WHERE MaHD IN (
                SELECT MaHD FROM HoaDon WHERE MaDatPhong = ?
            )
        """;
            XJDBC.update(sqlCTHD, maDatPhong);

            // Xóa hóa đơn
            String sqlHD = "DELETE FROM HoaDon WHERE MaDatPhong = ?";
            XJDBC.update(sqlHD, maDatPhong);

            // Xóa đặt phòng
            String sqlDP = "DELETE FROM DatPhong WHERE MaDatPhong = ?";
            XJDBC.update(sqlDP, maDatPhong);

        } catch (Exception e) {
            throw new RuntimeException("Lỗi khi xóa đặt phòng", e);
        }
    }
}
